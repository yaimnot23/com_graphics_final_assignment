import * as THREE from 'three';
import * as BufferGeometryUtils from 'addons/utils/BufferGeometryUtils.js';
import { computeBoundsTree, disposeBoundsTree, acceleratedRaycast, MeshBVHHelper, MeshBVH } from 'three-mesh-bvh';
import { OrbitControls } from 'addons/controls/OrbitControls.js';
import { Camera } from 'three';

const orbitcontrol_activate = true;
const show_collision_helpers = true;

var Colors = {
    red:0xf25346,
    white:0xd8d0d1,
    brown:0x59332e,
    pink:0xF5986E,
    brownDark:0x23190f,
    blue:0x68c3c0,
};

var scene,
        camera, fieldOfView, aspectRatio, nearPlane, farPlane, HEIGHT, WIDTH,
        renderer, container;
var mousePos = {x:0, y:0};
var targetPos = {x:0, y:0, z:0};
var targetMesh;
var cameraZig;
var controls;
let torus_radian = 0.01;
let torus_posY = 200;
var torusKnots = [];

var airplane_collider_box1, airplane_collider_box2;

var AirPlane = function(){
    this.mesh = new THREE.Object3D();
    
    // Create the cabin
    var geomCockpit = new THREE.BoxGeometry(80,50,50,1,1,1);
    let positionBuffer = geomCockpit.getAttribute('position');
    // we can access a specific vertex of a shape through 
    // the vertices array, and then move its x, y and z property:
    //console.log(positionBuffer);
    positionBuffer.array[4 * 3 + 1]-=10.0;
    positionBuffer.array[4 * 3 + 2]+=20.0;
    positionBuffer.array[5 * 3 + 1]-=10.0;
    positionBuffer.array[5 * 3 + 2]-=20.0;
    positionBuffer.array[6 * 3 + 1]+=30.0;
    positionBuffer.array[6 * 3 + 2]+=20.0;
    positionBuffer.array[7 * 3 + 1]+=30.0;
    positionBuffer.array[7 * 3 + 2]-=20.0;
    
    positionBuffer.array[8 * 3 + 1]-=10.0;
    positionBuffer.array[8 * 3 + 2]+=20.0;
    positionBuffer.array[10 * 3 + 1]-=10.0;
    positionBuffer.array[10 * 3 + 2]-=20.0;
    positionBuffer.array[12 * 3 + 1]+=30.0;
    positionBuffer.array[12 * 3 + 2]-=20.0;
    positionBuffer.array[14 * 3 + 1]+=30.0;
    positionBuffer.array[14 * 3 + 2]+=20.0;

    positionBuffer.array[16 * 3 + 1]-=10.0;
    positionBuffer.array[16 * 3 + 2]-=20.0;
    positionBuffer.array[18 * 3 + 1]+=30.0;
    positionBuffer.array[18 * 3 + 2]-=20.0;
    positionBuffer.array[21 * 3 + 1]-=10.0;
    positionBuffer.array[21 * 3 + 2]+=20.0;
    positionBuffer.array[23 * 3 + 1]+=30.0;
    positionBuffer.array[23 * 3 + 2]+=20.0;

    //console.log(positionBuffer.array[13]);
    //positionBuffer.needsUpdate = true;

    var matCockpit = new THREE.MeshPhongMaterial({color:Colors.red, flatShading:true});
    var cockpit = new THREE.Mesh(geomCockpit, matCockpit);
    cockpit.castShadow = true;
    cockpit.receiveShadow = true;
    this.mesh.add(cockpit);
    
    let axisHelper = new THREE.AxesHelper(100);
    cockpit.add(axisHelper);

    // Create the engine
    var geomEngine = new THREE.BoxGeometry(20,50,50,1,1,1);
    var matEngine = new THREE.MeshPhongMaterial({color:Colors.white, flatShading:true});
    var engine = new THREE.Mesh(geomEngine, matEngine);
    engine.position.x = 40;
    engine.castShadow = true;
    engine.receiveShadow = true;
    this.mesh.add(engine);
    
    // Create the tail
    var geomTailPlane = new THREE.BoxGeometry(15,20,5,1,1,1);
    var matTailPlane = new THREE.MeshPhongMaterial({color:Colors.red, flatShading:true});
    var tailPlane = new THREE.Mesh(geomTailPlane, matTailPlane);
    tailPlane.position.set(-35,25,0);
    tailPlane.castShadow = true;
    tailPlane.receiveShadow = true;
    this.mesh.add(tailPlane);

    const textureLoader = new THREE.TextureLoader();
    const texture = textureLoader.load('./test.jpg', () => {
        
        // Create the wing
        var geomSideWing = new THREE.BoxGeometry(40,8,150,1,1,1);
        
        let uvWingBuffer = geomSideWing.getAttribute('uv');

        // you need to code here :)
        // modify uvWingBuffer's uv coordinates
        // modify texture's sampling(filtering) options
        
        for (let i = 0; i < 24; i++)
        {
            uvWingBuffer.array[i * 2 + 0] = 0;
            uvWingBuffer.array[i * 2 + 1] = 0;
        }

        let ratio = texture.image.width / texture.image.height;
        uvWingBuffer.array[2 * 8 + 0] = 0;
        uvWingBuffer.array[2 * 8 + 1] = 0;
        uvWingBuffer.array[2 * 9 + 0] = 0;
        uvWingBuffer.array[2 * 9 + 1] = 1;
        uvWingBuffer.array[2 * 10 + 0] = 1 * ratio;
        uvWingBuffer.array[2 * 10 + 1] = 0;
        uvWingBuffer.array[2 * 11 + 0] = 1 * ratio;
        uvWingBuffer.array[2 * 11 + 1] = 1;

        texture.wrapS = THREE.MirroredRepeatWrapping;
        texture.wrapT = THREE.MirroredRepeatWrapping;
        texture.anisotropy = 16;
        //texture.minFilter = THREE.NearestFilter;
        
        var matSideWing1 = new THREE.MeshPhongMaterial({color:Colors.white, flatShading:true, map:texture});


        const matSideWing = new THREE.MeshPhysicalMaterial({
            transmission: 0.3,    // 투명도
            thickness: 1.0,       // 굴절 표현 깊이
            roughness: 0,
            metalness: 0,
            ior: 1.5,             // 유리 굴절률
            transparent: true,
            envMap: scene.background
        });



        var sideWing = new THREE.Mesh(geomSideWing, matSideWing);
        console.log(geomSideWing);
        sideWing.castShadow = true;
        sideWing.receiveShadow = true;
        this.mesh.add(sideWing);
    });
    
    //let posWingBuffer = geomSideWing.getAttribute('position');
    //var testSphere = new THREE.SphereGeometry(10,10,10);
    //var matTest = new THREE.MeshPhongMaterial({color:Colors.white, flatShading:true});
    //var testSphereMesh = new THREE.Mesh(testSphere, matTest);
    //const i = 19; // 0 ~ 23
    //testSphereMesh.position.set(
    //	posWingBuffer.array[i * 3 + 0],
    //	posWingBuffer.array[i * 3 + 1],
    //	posWingBuffer.array[i * 3 + 2]
    //)
    //sideWing.add(testSphereMesh);
    
    // propeller
    var geomPropeller = new THREE.BoxGeometry(20,10,10,1,1,1);
    var matPropeller = new THREE.MeshPhongMaterial({color:Colors.brown, flatShading:true});
    this.propeller = new THREE.Mesh(geomPropeller, matPropeller);
    this.propeller.castShadow = true;
    this.propeller.receiveShadow = true;
    
    // blades
    var geomBlade = new THREE.BoxGeometry(1,100,20,1,1,1);
    var matBlade = new THREE.MeshPhongMaterial({color:Colors.brownDark, flatShading:true});
    
    var blade = new THREE.Mesh(geomBlade, matBlade);
    blade.position.set(8,0,0);
    blade.castShadow = true;
    blade.receiveShadow = true;
    this.propeller.add(blade);
    this.propeller.position.set(50,0,0);
    this.mesh.add(this.propeller);

    this.mesh.position.y = 100;
    targetPos.x = this.mesh.position.x;
    targetPos.y = this.mesh.position.y;
    targetPos.z = this.mesh.position.z;

    targetMesh.position.set(targetPos.x, targetPos.y, targetPos.z);
    
    targetQuat = new THREE.Quaternion();
    startQuat = new THREE.Quaternion();
    endQuat = new THREE.Quaternion();

    startCamQuat = new THREE.Quaternion();
    endCamQuat = new THREE.Quaternion();


    const box1 = new THREE.Box3(
        new THREE.Vector3(-50,-28,-30),
        new THREE.Vector3(50,35,30)
    );    
    const box2 = new THREE.Box3(
        new THREE.Vector3(-22, -5, -77),
        new THREE.Vector3(22, 5, 77)
    );

    if (show_collision_helpers)
    {
        const helper1 = new THREE.Box3Helper(box1, 0xff0000); // 색상은 선택
        const helper2 = new THREE.Box3Helper(box2, 0x00ff00); // 색상은 선택

        this.mesh.add(helper1);
        this.mesh.add(helper2);
    }
    airplane_collider_box1 = box1;
    airplane_collider_box2 = box2;
};

class Pilot{
    constructor() {
        this.mesh = new THREE.Object3D();
        this.mesh.name = "pilot";
        this.mesh.position.y = 30;
        //this.mesh.position = new THREE.Vector3(0, 100, 0);
        
        // angleHairs is a property used to animate the hair later 
        this.angleHairs=0;

        // Body of the pilot
        var bodyGeom = new THREE.BoxGeometry(15,15,15);
        var bodyMat = new THREE.MeshPhongMaterial({color:Colors.brown, flatShading:true});
        var body = new THREE.Mesh(bodyGeom, bodyMat);
        body.position.set(2,-12,0);
        this.mesh.add(body);

        // Face of the pilot
        var faceGeom = new THREE.BoxGeometry(10,10,10);
        var faceMat = new THREE.MeshLambertMaterial({color:Colors.pink});
        var face = new THREE.Mesh(faceGeom, faceMat);
        this.mesh.add(face);

        // Hair element
        var hairGeom = new THREE.BoxGeometry(4,4,4);
        var hairMat = new THREE.MeshLambertMaterial({color:Colors.brown});
        var hair = new THREE.Mesh(hairGeom, hairMat);
        // Align the shape of the hair to its bottom boundary, that will make it easier to scale.
        hair.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0,2,0));
        
        // create a container for the hair
        var hairs = new THREE.Object3D();

        // create a container for the hairs at the top 
        // of the head (the ones that will be animated)
        this.hairsTop = new THREE.Object3D();

        // create the hairs at the top of the head 
        // and position them on a 3 x 4 grid
        for (var i=0; i<12; i++){
            var h = hair.clone();
            var col = i%3;
            var row = Math.floor(i/3);
            var startPosZ = -4;
            var startPosX = -4;
            h.position.set(startPosX + row*4, 0, startPosZ + col*4);
            this.hairsTop.add(h);
        }
        hairs.add(this.hairsTop);

        // create the hairs at the side of the face
        var hairSideGeom = new THREE.BoxGeometry(12,4,2);
        hairSideGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(-6,0,0));
        var hairSideR = new THREE.Mesh(hairSideGeom, hairMat);
        var hairSideL = hairSideR.clone();
        hairSideR.position.set(8,-2,6);
        hairSideL.position.set(8,-2,-6);
        hairs.add(hairSideR);
        hairs.add(hairSideL);

        // create the hairs at the back of the head
        var hairBackGeom = new THREE.BoxGeometry(2,8,10);
        var hairBack = new THREE.Mesh(hairBackGeom, hairMat);
        hairBack.position.set(-1,-4,0)
        hairs.add(hairBack);
        hairs.position.set(-5,5,0);

        this.mesh.add(hairs);

        var glassGeom = new THREE.BoxGeometry(5,5,5);
        var glassMat = new THREE.MeshLambertMaterial({
            color:Colors.brown, 
            transparent:true,
            opacity:.6,});
        var glassR = new THREE.Mesh(glassGeom,glassMat);
        glassR.position.set(6,0,3);
        var glassL = glassR.clone();
        glassL.position.z = -glassR.position.z

        var glassAGeom = new THREE.BoxGeometry(1,21,21);
        var glassAMat = new THREE.MeshLambertMaterial({
            color:Colors.white, 
            transparent:true,
            opacity:.3,});
        var glassA = new THREE.Mesh(glassAGeom, glassAMat);
        glassA.position.set(15,3,3);
        this.mesh.add(glassR);
        this.mesh.add(glassL);
        this.mesh.add(glassA);

        var earGeom = new THREE.BoxGeometry(2,3,2);
        var earL = new THREE.Mesh(earGeom,faceMat);
        earL.position.set(0,0,-6);
        var earR = earL.clone();
        earR.position.set(0,0,6);
        this.mesh.add(earL);
        this.mesh.add(earR);
    }

    // move the hair
    updateHairs()
    {
        // get the hair
        var hairs = this.hairsTop.children;

        // update them according to the angle angleHairs
        var l = hairs.length;
        for (var i=0; i<l; i++){
            var h = hairs[i];
            // each hair element will scale on cyclical basis between 75% and 100% of its original size
            h.scale.y = .75 + Math.cos(this.angleHairs+i/3)*.25;
        }
        // increment the angle for the next frame
        this.angleHairs += 0.16;
    }
}

// First let's define a Sea object :
class Sea{
    constructor(){
    
        var geom = new THREE.CylinderGeometry(600,600,800,40,10);
        geom.applyMatrix4(new THREE.Matrix4().makeRotationX(-Math.PI/2));

        let uvBuffer = geom.getAttribute('uv');
        delete uvBuffer.array;
        delete geom.attributes['uv'];
        
        let normalBuffer = geom.getAttribute('normal');
        delete normalBuffer.array;
        delete geom.attributes['normal'];
        console.log(geom);

        // important: by merging vertices we ensure the continuity of the waves
        geom = BufferGeometryUtils.mergeVertices(geom);
        geom.computeVertexNormals();
        let positionBuffer = geom.getAttribute('position');
        let positions = positionBuffer.array;
        //console.log(positionBuffer.count);

        // get the vertices
        var l = positionBuffer.count;

        // create an array to store new data associated to each vertex
        this.waves = [];


        for (var i=0; i<l; i++){
            // get each vertex
            let v = new THREE.Vector3(positions[3*i + 0], positions[3*i + 1], positions[3*i + 2]);

            // store some data associated to it
            this.waves.push({y:v.y,
                                            x:v.x,
                                            z:v.z,
                                            // a random angle
                                            ang:Math.random()*Math.PI*2,
                                            // a random distance
                                            amp:5 + Math.random()*15,
                                            // a random speed between 0.016 and 0.048 radians / frame
                                            speed:0.016 + Math.random()*0.032
                                            });
        };
        var mat = new THREE.MeshPhongMaterial({
            color:Colors.blue,
            //transparent:true,
            opacity:1.0,
            flatShading:false,
            shininess:1000,
            specular:0xFFFFFF
        });
        mat.specular = new THREE.Color(255, 255, 255);

        this.mesh = new THREE.Mesh(geom, mat);
        this.mesh.receiveShadow = true;
    }

    moveWaves(){
    
        // get the vertices
        var positionBuffer = this.mesh.geometry.getAttribute('position');
        var l = positionBuffer.count;
        let positions = positionBuffer.array;

        //console.log(verts);
        
        for (var i=0; i<l; i++){
            //var v = positions[3 * i];
            
            // get the data associated to it
            var vprops = this.waves[i];
            
            // update the position of the vertex
            positions[3 * i + 0] = vprops.x + Math.cos(vprops.ang)*vprops.amp;
            positions[3 * i + 1] = vprops.y + Math.sin(vprops.ang)*vprops.amp;
    
            // increment the angle for the next frame
            vprops.ang += vprops.speed;
    
        }
    
        // Tell the renderer that the geometry of the sea has changed.
        // In fact, in order to maintain the best level of performance, 
        // three.js caches the geometries and ignores any changes
        // unless we add this line
        this.mesh.geometry.verticesNeedUpdate=true;
    
        sea.mesh.rotation.z += .005;
    }
}

var Cloud = function(){
    // Create an empty container that will hold the different parts of the cloud
    this.mesh = new THREE.Object3D();
    
    // create a cube geometry;
    // this shape will be duplicated to create the cloud
    var geom = new THREE.BoxGeometry(20,20,20);
    
    // create a material; a simple white material will do the trick
    var mat = new THREE.MeshPhongMaterial({
        color:Colors.white,  
    });
    
    // duplicate the geometry a random number of times
    var nBlocs = 3+Math.floor(Math.random()*3);
    for (var i=0; i<nBlocs; i++ ){
        
        // create the mesh by cloning the geometry
        var m = new THREE.Mesh(geom, mat); 
        
        // set the position and the rotation of each cube randomly
        m.position.x = i*15;
        m.position.y = Math.random()*10;
        m.position.z = Math.random()*10;
        m.rotation.z = Math.random()*Math.PI*2;
        m.rotation.y = Math.random()*Math.PI*2;
        
        // set the size of the cube randomly
        var s = .1 + Math.random()*.9;
        m.scale.set(s,s,s);
        
        // allow each cube to cast and to receive shadows
        m.castShadow = true;
        m.receiveShadow = true;
        
        // add the cube to the container we first created
        this.mesh.add(m);
    } 
}

// Define a Sky Object
var Sky = function(){
    // Create an empty container
    this.mesh = new THREE.Object3D();
    
    // choose a number of clouds to be scattered in the sky
    this.nClouds = 20;
    
    // To distribute the clouds consistently,
    // we need to place them according to a uniform angle
    var stepAngle = Math.PI*2 / this.nClouds;

    // create the clouds
    for(var i=0; i<this.nClouds; i++){
        var c = new Cloud();
     
        // set the rotation and the position of each cloud;
        // for that we use a bit of trigonometry
        var a = stepAngle*i; // this is the final angle of the cloud
        var h = 750 + Math.random()*200; // this is the distance between the center of the axis and the cloud itself

        // Trigonometry!!! I hope you remember what you've learned in Math :)
        // in case you don't: 
        // we are simply converting polar coordinates (angle, distance) into Cartesian coordinates (x, y)
        c.mesh.position.y = Math.sin(a)*h;
        c.mesh.position.x = Math.cos(a)*h;

        // rotate the cloud according to its position
        c.mesh.rotation.z = a + Math.PI/2;

        // for a better result, we position the clouds 
        // at random depths inside of the scene
        c.mesh.position.z = 400-Math.random()*800;
        
        // we also set a random scale for each cloud
        var s = 1+Math.random()*2;
        c.mesh.scale.set(s,s,s);

        // do not forget to add the mesh of each cloud in the scene
        this.mesh.add(c.mesh);  
    }  
}

function init() {
    camViewChange = "none";
    camState = "fps";
    // set up the scene, the camera and the renderer
    createScene();

    // add the lights
    createLights();

    // add the objects
    createPlane();
    createSea();
    createSky();

    if (orbitcontrol_activate)
    {
        controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true; // 부드러운 움직임 추가
    }


    //add the listener
    document.addEventListener('keydown', handleKeyDown, false);
    //document.addEventListener('mousemove', handleMouseMove, false);

    loop();
}

const loader = new THREE.TextureLoader();
loader.load('./space2.webp', (texture) => {
    //texture.mapping = THREE.EquirectangularReflectionMapping;
    texture.mapping = THREE.EquirectangularRefractionMapping;
    scene.background = texture;
});

init();

function createPlane(){ 
    airplane = new AirPlane();
    airplane.mesh.scale.set(.25,.25,.25);
    airplane.mesh.position.y = 100;
    scene.add(airplane.mesh);

    airplane.pilot = new Pilot();
    airplane.mesh.add(airplane.pilot.mesh);
    //airplane.mesh.add(camera);

    cameraZig = new THREE.Object3D();
    cameraZig.scale.set(.25,.25,.25); // matches the scale factor to airplane
    scene.add(cameraZig);
    if (!orbitcontrol_activate)
    {
        cameraZig.add(camera);
    }

}

function createScene() {
    // Get the width and the height of the screen,
    // use them to set up the aspect ratio of the camera 
    // and the size of the renderer.
    HEIGHT = window.innerHeight;
    WIDTH = window.innerWidth;

    // Create the scene
    scene = new THREE.Scene();


    let axisHelper = new THREE.AxesHelper(50);
    scene.add(axisHelper);

    let targetHelper = new THREE.SphereGeometry(5, 20, 20);
    let targetHelperMat = new THREE.MeshPhongMaterial({color:Colors.white, flatShading:false});
    targetMesh = new THREE.Mesh(targetHelper, targetHelperMat);
    scene.add(targetMesh);


    // Add a fog effect to the scene; same color as the
    // background color used in the style sheet
    //scene.fog = new THREE.Fog(0xf7d9aa, 100, 950);
    scene.fog = new THREE.Fog(0xf7d9aa, 2000, 3950);
    
    // Create the camera
    aspectRatio = WIDTH / HEIGHT;
    fieldOfView = 60;
    nearPlane = 1;
    farPlane = 10000;
    camera = new THREE.PerspectiveCamera(
        fieldOfView,
        aspectRatio,
        nearPlane,
        farPlane
        );
    
    // Set the position of the camera
    ///camera.position.x = 0;
    //camera.position.z = 200;
    //camera.position.y = 100;
    
    if (!orbitcontrol_activate)
    {
        camera.position.x = -300;//-1200;
        camera.position.y = 100;//300;
        camera.position.z = 0;
    }
    else{
        camera.position.x = 0;
        camera.position.z = 400;
        camera.position.y = 400;
    }
    camera.lookAt(new THREE.Vector3(0, 0, 0));
    
    // Create the renderer
    renderer = new THREE.WebGLRenderer({ 
        // Allow transparency to show the gradient background
        // we defined in the CSS
        alpha: true, 

        // Activate the anti-aliasing; this is less performant,
        // but, as our project is low-poly based, it should be fine :)
        antialias: true 
    });

    // Define the size of the renderer; in this case,
    // it will fill the entire screen
    renderer.setSize(WIDTH, HEIGHT);
    
    // Enable shadow rendering
    renderer.shadowMap.enabled = true;
    
    // Add the DOM element of the renderer to the 
    // container we created in the HTML
    container = document.getElementById('world');
    container.appendChild(renderer.domElement);
    
    // Listen to the screen: if the user resizes it
    // we have to update the camera and the renderer size
    window.addEventListener('resize', handleWindowResize, false);
}

var airplane;
var sea;
var sky;
var hemisphereLight, shadowLight;
var targetQuat;
var startQuat, endQuat;
var slerpT = 0., camlerpT = 0.;
var moveDist = 30.;
var rotAngle = Math.PI / 1.5;
var eState = 0;
var startCamQuat, endCamQuat, startCamPos, endCamPos;
var camViewChange = "none";
var camState = "fps";

function handleKeyDown(e) {

    console.log(e.key);
    switch (e.key)
    {
        case "w": 
            targetPos.y = airplane.mesh.position.y + moveDist; 
            targetQuat.setFromAxisAngle(new THREE.Vector3( 0, 0, 1 ), rotAngle); 
            break;
        case "s": 
            targetPos.y = airplane.mesh.position.y - moveDist; 
            targetQuat.setFromAxisAngle(new THREE.Vector3( 0, 0, -1 ), rotAngle); 
            break;
        case "d": 
            targetPos.z = airplane.mesh.position.z + moveDist; 
            targetQuat.setFromAxisAngle(new THREE.Vector3( 1, 0, 0 ), rotAngle); 
            break;
        case "a": 
            targetPos.z = airplane.mesh.position.z - moveDist; 
            targetQuat.setFromAxisAngle(new THREE.Vector3( -1, 0, 0 ), rotAngle); 
            break;
        case "o": 
            //if (camState == "fps")
            //	return;
            camState = "fps";
            
            cameraZig.attach(camera);

            startCamQuat = camera.quaternion.clone();
            startCamPos = camera.position.clone();
            
            let targetCamFps = new THREE.Camera();
            targetCamFps.position.set(-500, 300, 0);
            targetCamFps.up.set(0, 1, 0);
            targetCamFps.lookAt(0, 0, 0);
            endCamQuat = targetCamFps.quaternion.clone();
            endCamPos = targetCamFps.position.clone();

            camViewChange = "toFps";
            camlerpT = 0.;

            return;
        case "i": 
            //if (camState == "fps")
            //	return;
            camState = "fps";
            
            cameraZig.attach(camera);

            startCamQuat = camera.quaternion.clone();
            startCamPos = camera.position.clone();
            
            let targetCamFps2 = new THREE.Camera();
            targetCamFps2.position.set(0, 300, 0);
            targetCamFps2.up.set(1, 0, 0);
            targetCamFps2.lookAt(0, 0, 0);
            endCamQuat = targetCamFps2.quaternion.clone();
            endCamPos = targetCamFps2.position.clone();

            camViewChange = "toFps";
            camlerpT = 0.;

            return;
        case "p":
            if (camState == "top")
                return;
            camState = "top";

            //console.log(camera.position);
            scene.attach(camera);
            //console.log(camera.position);
            
            startCamQuat = camera.quaternion.clone();
            startCamPos = camera.position.clone();

            let targetCamTop = new THREE.Camera();
            targetCamTop.position.set(0, 1000, 0);
            targetCamTop.up.set(1, 0, 0);
            targetCamTop.lookAt(0, 0, 0);
            endCamQuat = targetCamTop.quaternion.clone();
            endCamPos = targetCamTop.position.clone();

            camViewChange = "toTop";
            camlerpT = 0.;
            scene.fog = new THREE.Fog(0xf7d9aa, 20000, 39500);

            return;
        default: return;
    }
    startQuat.copy(airplane.mesh.quaternion); 
    targetMesh.position.set(targetPos.x, targetPos.y, targetPos.z);
    slerpT = 0.;
    eState = 1;
}

function handleWindowResize() {
    // update height and width of the renderer and the camera
    HEIGHT = window.innerHeight;
    WIDTH = window.innerWidth;
    renderer.setSize(WIDTH, HEIGHT);
    camera.aspect = WIDTH / HEIGHT;
    camera.updateProjectionMatrix();
}

function createLights() {
    // A hemisphere light is a gradient colored light; 
    // the first parameter is the sky color, the second parameter is the ground color, 
    // the third parameter is the intensity of the light
    hemisphereLight = new THREE.HemisphereLight(0xaaaaaa,0x000000, .9)
    
    // A directional light shines from a specific direction. 
    // It acts like the sun, that means that all the rays produced are parallel. 
    shadowLight = new THREE.DirectionalLight(0xffffff, .9);

    // Set the direction of the light  
    shadowLight.position.set(150, 350, 350);
    
    // Allow shadow casting 
    shadowLight.castShadow = true;

    // define the visible area of the projected shadow
    shadowLight.shadow.camera.left = -400;
    shadowLight.shadow.camera.right = 400;
    shadowLight.shadow.camera.top = 400;
    shadowLight.shadow.camera.bottom = -400;
    shadowLight.shadow.camera.near = 1;
    shadowLight.shadow.camera.far = 1000;

    // define the resolution of the shadow; the higher the better, 
    // but also the more expensive and less performant
    shadowLight.shadow.mapSize.width = 2048;
    shadowLight.shadow.mapSize.height = 2048;
    
    // to activate the lights, just add them to the scene
    scene.add(hemisphereLight);  
    scene.add(shadowLight);

    // an ambient light modifies the global color of a scene and makes the shadows softer
    let ambientLight = new THREE.AmbientLight(0xdc8874, 1.0);
    scene.add(ambientLight);
}

function createSea(){
    sea = new Sea();

    // push it a little bit at the bottom of the scene
    sea.mesh.position.y = -600;

    // add the mesh of the sea to the scene
    scene.add(sea.mesh);
}

function createSky(){
    sky = new Sky();
    sky.mesh.position.y = -600;
    scene.add(sky.mesh);

    const geometry = new THREE.TorusKnotGeometry( 200, 10, 100, 16 ); 
    const torusKnot_bvh = new MeshBVH(geometry);
    geometry.boundsTree = torusKnot_bvh;

    for (let i = 0; i < 3; i++)
    {
        const material = new THREE.MeshPhongMaterial( { color: 0xffff00 } ); 
        const torusKnot = new THREE.Mesh( geometry, material ); 
        scene.add( torusKnot );

        if (show_collision_helpers)
        {
            const helperMesh = new MeshBVHHelper( torusKnot );
            helperMesh.color.set( 0xE91E63 );
            scene.add( helperMesh );
        }

        torusKnots.push(torusKnot);
    }

}

function loop(){
    // Rotate the propeller, the sea and the sky
    airplane.propeller.rotation.x += 0.3;
    sea.mesh.rotation.z += .0005;
    sky.mesh.rotation.z += .001;
    //torusKnot.rotation.z += .01;
    //torusKnot.rotation.y += .01;
    //torusKnot.rotation.x += .01;
    scene.backgroundRotation.z += 0.001;

    const t_xs = [0, 400, -400]
    const t_ys = [800, -800, 600]
    const t_zs = [0, 400, -400]
    
    torus_radian = torus_radian + 0.01;
    for (let i = 0; i < 3; i++)
    {
        let torusKnot = torusKnots[i];
        torusKnot.matrixAutoUpdate = true;
        {
            const T0 = new THREE.Matrix4().makeTranslation(
                t_xs[i],
                t_ys[i],
                t_zs[i]
            );
            const T1 = new THREE.Matrix4().makeTranslation(
                0,
                -600,
                0
            );
            const euler = new THREE.Euler(
                torus_radian, 
                torus_radian, 
                torus_radian, 
                'XYZ' 
            );
            const R1 = new THREE.Matrix4().makeRotationFromEuler(euler);
            const R0 = new THREE.Matrix4().makeRotationZ(torus_radian);
            T1.multiply(new THREE.Matrix4().multiplyMatrices(R0.multiply(T0), R1));
            torusKnot.matrix.copy(T1);
            torusKnot.updateWorldMatrix();
        }
    }
    airplane.mesh.updateWorldMatrix();

    airplane.pilot.updateHairs();
    sea.moveWaves();

    // update the plane on each frame
    updatePlane();
    updateCameraFov();

    // render the scene
    
    if (orbitcontrol_activate)
    {
        controls.update(); 
    }

    const airplane2world = new THREE.Matrix4().copy(airplane.mesh.matrixWorld);
    for (let i = 0; i < 3; i++)
    {
        let torusKnot = torusKnots[i];
        const world2torus = new THREE.Matrix4().copy(torusKnot.matrixWorld).invert();
        const airplane2torus = new THREE.Matrix4().multiplyMatrices(world2torus, airplane2world);
        const intersects1 = torusKnot.geometry.boundsTree.intersectsBox(airplane_collider_box1, airplane2torus);
        const intersects2 = torusKnot.geometry.boundsTree.intersectsBox(airplane_collider_box2, airplane2torus);
        if (intersects1 || intersects2)
        {
            torusKnot.material.color.set(0xff0000);
        }
        else
        {
            torusKnot.material.color.set(0xffff00);
        }
    }

    renderer.render(scene, camera);

    // call the loop function again
    requestAnimationFrame(loop);
}

/////////////////////
// Follow the Mouse: Adding Interaction

// now handle the mousemove event

function handleMouseMove(event) {

    // here we are converting the mouse position value received 
    // to a normalized value varying between -1 and 1;
    // this is the formula for the horizontal axis:
    
    var tx = -1 + (event.clientX / WIDTH)*2;

    // for the vertical axis, we need to inverse the formula 
    // because the 2D y-axis goes the opposite direction of the 3D y-axis
    
    var ty = 1 - (event.clientY / HEIGHT)*2;
    mousePos = {x:tx, y:ty};

}

function updatePlaneOld2(){

    // let's move the airplane between -100 and 100 on the horizontal axis, 
    // and between 25 and 175 on the vertical axis,
    // depending on the mouse position which ranges between -1 and 1 on both axes;
    // to achieve that we use a normalize function (see below)
    var targetX = normalize(mousePos.x, -1, 1, -100, 100);
    var targetY = normalize(mousePos.y, -1, 1, 25, 175);

    // update the airplane's position
    airplane.mesh.position.y = targetY;
    airplane.mesh.position.x = targetX;
    airplane.propeller.rotation.x += 0.3;
}

function updatePlaneOld(){
    var targetY = normalize(mousePos.y,-.75,.75,25, 175);
    var targetX = normalize(mousePos.x,-.75,.75,-100, 100);
    
    // Move the plane at each frame by adding a fraction of the remaining distance
    airplane.mesh.position.y += (targetY-airplane.mesh.position.y)*0.1;

    // Rotate the plane proportionally to the remaining distance
    airplane.mesh.rotation.z = (targetY-airplane.mesh.position.y)*0.0128;
    airplane.mesh.rotation.x = (airplane.mesh.position.y-targetY)*0.0064;

    airplane.propeller.rotation.x += 0.3;
}

var midQuat = new THREE.Quaternion();
function updatePlaneSkeleton(){
    var targetY = targetPos.y;
    var targetZ = targetPos.z;
    
    // Move the plane at each frame by adding a fraction of the remaining distance
    airplane.mesh.position.y += (targetY-airplane.mesh.position.y)*0.1;
    airplane.mesh.position.z += (targetZ-airplane.mesh.position.z)*0.1;

    let tY = Math.abs(airplane.mesh.position.y - targetY);
    let tZ = Math.abs(airplane.mesh.position.z - targetZ);
    let t = 1. - Math.max(tY, tZ) / 30.;

    if (t <= 0.5)
    {
        // update airplane.mesh.quaternion by using slerpQuaternions with t
        // and then set midQuat to airplane.mesh.quaternion, i.e, midQuat.copy(airplane.mesh.quaternion); 
    }
    else if (slerpT <= 1.0)
    {
        // update airplane.mesh.quaternion by using slerpQuaternions with slerpT
        // increase slerpT by small value
    }
    airplane.propeller.rotation.x += 0.2;
}

function updatePlane1(){
    var targetY = targetPos.y;
    var targetZ = targetPos.z;
    
    // Move the plane at each frame by adding a fraction of the remaining distance
    airplane.mesh.position.y += (targetY-airplane.mesh.position.y)*0.1;
    airplane.mesh.position.z += (targetZ-airplane.mesh.position.z)*0.1;

    // Rotate the plane proportionally to the remaining distance
    airplane.mesh.rotation.z = (targetY-airplane.mesh.position.y)*0.0128;
    airplane.mesh.rotation.x = (targetZ - airplane.mesh.position.z)*0.0064;

    airplane.propeller.rotation.x += 0.2;
}

function updatePlane(){
    var targetY = targetPos.y;
    var targetZ = targetPos.z;
    
    // Move the plane at each frame by adding a fraction of the remaining distance
    airplane.mesh.position.y += (targetY-airplane.mesh.position.y)*0.1;
    airplane.mesh.position.z += (targetZ-airplane.mesh.position.z)*0.1;	

    let tY = Math.abs(airplane.mesh.position.y - targetY);
    let tZ = Math.abs(airplane.mesh.position.z - targetZ);
    let t = 1. - Math.max(tY, tZ) / 30.;

    if (t <= 0.5)
    {
        airplane.mesh.quaternion.slerpQuaternions(startQuat, targetQuat, Math.min(slerpT, 1.));
        midQuat.copy(airplane.mesh.quaternion);
        slerpT += 0.05;
        //targetQuat.set(airplane.mesh.quaternion.x, airplane.mesh.quaternion.y, airplane.mesh.quaternion.z, airplane.mesh.quaternion.w);
        //airplane.mesh.quaternion.set(targetQuat.x, targetQuat.y, targetQuat.z, targetQuat.w); 
    }
    else if (eState == 1)
    {
        slerpT = 0.;
        eState = 2;
    }


    if (eState == 2)
    {
        airplane.mesh.quaternion.slerpQuaternions(midQuat, endQuat, Math.min(slerpT, 1.));
        //airplane.mesh.quaternion.slerpQuaternions(targetQuat, eqQuat, Math.min(slerpT - 0.5, 1.));
        //airplane.mesh.quaternion.slerp(eqQuat, Math.min(slerpT - 0.5, 1.));
        slerpT += 0.05;
        //targetQuat.setFromAxisAngle(new THREE.Vector3(0, 0, 1), 0);
    }
    cameraZig.position.copy(airplane.mesh.position);

    // matrix 로 모두 하면 추가점 10% //
    // 다음 과제 ...
    // 2. special VFX...
    // 3. 게임의 추가 요소 + 특수 그래픽스 효과 (부스트 등등...) //

    airplane.propeller.rotation.x += 0.2;

    if (camViewChange != "none" && !orbitcontrol_activate) 
    {
        //camera.position.x += (endCamPos.x - camera.position.x);
        //camera.position.y += (endCamPos.y - camera.position.y);
        //camera.position.z += (endCamPos.z - camera.position.z);
        camera.position.lerpVectors(startCamPos, endCamPos, Math.min(camlerpT, 1.));
        camera.quaternion.slerpQuaternions(startCamQuat, endCamQuat, Math.min(camlerpT, 1.));
        if (camlerpT > 1.)
        {
            camViewChange = "none";
            camlerpT = 0.;
        }
        camlerpT += 0.02;
    }
}


function updateCameraFov(){
    camera.fov = normalize(mousePos.x,-1,1,40, 80);
    camera.updateProjectionMatrix();
  }

function normalize(v,vmin,vmax,tmin, tmax){

    var nv = Math.max(Math.min(v,vmax), vmin);
    var dv = vmax-vmin;
    var pc = (nv-vmin)/dv;
    var dt = tmax-tmin;
    var tv = tmin + (pc*dt);
    return tv;

}

